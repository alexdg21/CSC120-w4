﻿using System;
namespace W2
{
    public class GateInput2
    { 
        public bool A { get; set; }

        public bool B { get; set; }

        public bool C { get; set; }

    }
}
