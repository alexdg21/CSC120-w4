﻿using System;
namespace W2
{
    public class OrGates
    {
        public static bool InPut(bool x, bool y)
        {
            return (x || y);
        }
    }
}
