﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W2
{
    public class NotGates
    {
        public static bool InPut(bool x)
        {
                return !x;
            
        }
    }
}